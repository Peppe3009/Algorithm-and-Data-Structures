#include <vector>
#include <iostream>
#include <string>
using namespace std;
class MaxHeap
{
private:
    
    int heapSize;
    vector<int> heapVector;
    int parent(int);
    int right(int);
    int left(int);
    void maxHeapify(int);
    void swap(int, int);
    
public:
    MaxHeap();
    MaxHeap(vector<int>);
    MaxHeap(string);
    void buildMaxHeap();
    void heapInsert(int);
    void showHeap();
    void save();
    void save(string);
    
};