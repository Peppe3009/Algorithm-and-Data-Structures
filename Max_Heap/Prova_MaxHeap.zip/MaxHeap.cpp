#include "MaxHeap.h"
#include <fstream>
#include <cmath>



MaxHeap::MaxHeap()
{
    this->heapSize = 0;
    vector tempVector(this->heapSize, 0);
    this->heapVector = tempVector;
}


MaxHeap::MaxHeap(vector<int> externalVector)
{
    this->heapVector = externalVector;
}


MaxHeap::MaxHeap(string filename)
{
    ifstream inputFile(filename);
    int numero;
    if (!inputFile)
    {
        cerr << "Errore. File non esistente";
    }
    while (!inputFile.eof())
    {
        inputFile >> numero;
        this->heapVector.push_back(numero);
    }
}


int MaxHeap::parent(int i)
{
    return floor((i - 1) / 2);
}


int MaxHeap::right(int i)
{
    return 2 * i + 2;
}


int MaxHeap::left(int i)
{
    return 2 * i + 1;
}


void MaxHeap::swap(int i, int j)
{
    int temp = this->heapVector.at(i);
    this->heapVector.at(i) = this->heapVector.at(j);
    this->heapVector.at(j) = temp;
}


void MaxHeap::maxHeapify(int i)
{
    int l = this->left(i);
    int r = this->right(i);
    int maggiore = 0;
    if (l<this->heapSize &&this->heapVector.at(l)> this->heapVector.at(i))
    {
        maggiore = l;
    }
    else
    {
        maggiore = i;
    }
    if (r<this->heapSize &&this->heapVector.at(r)> this->heapVector.at(maggiore))
    {
        maggiore = r;
    }
    if (maggiore != i)
    {
        this->swap(i, maggiore);
        this->maxHeapify(maggiore);
    }
}


void MaxHeap::buildMaxHeap()
{
    this->heapSize = this->heapVector.size();
    for (int i = ((this->heapVector.size() - 1) / 2); i >= 0; i--)
    {
        this->maxHeapify(i);
    }
}


void MaxHeap::heapInsert(int key)
{
    this->heapSize++;
    this->heapVector.resize(this->heapVector.size() + 1);
    int i = this->heapSize - 1;
    while (i >= 0 && this->heapVector.at(parent(i)) < key)
    {
        this->heapVector.at(i) = this->heapVector.at(parent(i));
        i = parent(i);
    }
    this->heapVector.at(i) = key;
}


void MaxHeap::showHeap()
{
    cout << "Heap: ";
    for (int i = 0; i < this->heapVector.size(); i++)
    {
        cout << this->heapVector.at(i) << " ";
    }
    cout << endl;
}


void MaxHeap::save()
{
    string filename = "OUT.txt";
    ofstream outputFile(filename);
    outputFile << "Heap: ";
    for (int i = 0; i < this->heapVector.size(); i++)
    {
        outputFile << this->heapVector.at(i) << " ";
    }
    outputFile.close();
}


void MaxHeap::save(string filename)
{
    ofstream outputFile(filename);
    outputFile << "Heap: ";
    for (int i = 0; i < this->heapVector.size(); i++)
    {
        outputFile << this->heapVector.at(i) << " ";
    }

    outputFile.close();
}
